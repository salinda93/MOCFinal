package design.patterns.q2;

public abstract class TV {
	
	public String model;
	
	public String size;
	
	public abstract void display();

}
