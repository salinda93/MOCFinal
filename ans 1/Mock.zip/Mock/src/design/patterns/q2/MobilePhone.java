package design.patterns.q2;

public abstract class MobilePhone {
	
	public String model;
	
	public double price;
	
	public abstract void display();

}
